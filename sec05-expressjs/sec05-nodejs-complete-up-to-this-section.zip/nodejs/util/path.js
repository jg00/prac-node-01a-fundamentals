const path = require("path");

// console.log("rootDir:", path.dirname(process.mainModule.filename));

module.exports = path.dirname(process.mainModule.filename);
