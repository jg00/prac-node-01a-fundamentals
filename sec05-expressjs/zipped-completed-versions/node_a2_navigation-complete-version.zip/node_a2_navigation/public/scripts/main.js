alert("Main script alert!");
